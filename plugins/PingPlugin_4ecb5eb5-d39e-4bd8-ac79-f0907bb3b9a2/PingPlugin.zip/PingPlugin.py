import aiohttp
from core.plugins import Plugin
from core.utils.logger import get_logger

class PingPlugin(Plugin):
    def __init__(self, bot_client):
        super().__init__(bot_client)
        self.name = "PingPlugin"
        self.logger = get_logger()

    async def before_llm_message(self, message):
        cleaned_content = message.content.strip().lower()
        
        if cleaned_content.startswith('/ping '):
            ip_address = cleaned_content[6:].strip()
            response = await self.ping(ip_address)
            group_id = message.group_openid
            await self.bot_client.send_message(group_id, response)
            return False  # Skip LLM processing
        
        return True  # Continue LLM processing

    async def ping(self, host):
        url = f"https://uapis.cn/api/ping?host={host}"
        try:
            async with aiohttp.ClientSession() as session:
                async with session.get(url) as response:
                    data = await response.json()
                    if response.status == 200:
                        return f"Ping to {data['host']} ({data['ip']}) successful: Max: {data['max']}ms, Avg: {data['avg']}ms, Min: {data['min']}ms"
                    elif response.status == 422:
                        return f"Error: {data.get('msg', 'Invalid IP')}"
                    elif response.status == 500:
                        return "Error: Failed to ping the host"
                    else:
                        return "Unexpected error occurred."
        except Exception as e:
            self.logger.error(f"An error occurred while pinging: {e}")
            return "Error: Unable to perform ping due to an exception."