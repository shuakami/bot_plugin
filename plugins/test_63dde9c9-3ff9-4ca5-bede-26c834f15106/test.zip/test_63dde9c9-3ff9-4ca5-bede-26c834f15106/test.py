# test.py
import random
from core.plugins import Plugin
from core.plugins.tools.plugin_utils import load_plugin_config
from core.utils.logger import get_logger

logger = get_logger()

class {plugin_class_name}(Plugin):
    def __init__(self, bot_client):
        super().__init__(bot_client)
        self.name = "test"           
        self.custom_replies = load_plugin_config(__name__, "test.json")# 此处是插件的配置文件（可选）
        if not self.custom_replies:
            logger.error("<ERROR> 🚨无法加载自定义回复，插件将无法正常工作。")
        else:
            logger.info("<PLUGIN INIT> {plugin_class_name} 初始化成功")
            logger.debug(f"   ↳ 加载的自定义回复: {self.custom_replies}")

    async def on_message(self, message, reply_message):
        try:
            logger.debug("<PLUGIN EXEC> {plugin_class_name} 被调用:")
            if self.custom_replies:
                custom_reply = random.choice(self.custom_replies)
                if reply_message:
                    reply_message = f"{reply_message}\n---\n{custom_reply}"
                else:
                    reply_message = custom_reply
                logger.info("<REPLY ADDED> 添加自定义回复: {custom_reply}")
            else:
                logger.warning("<PLUGIN SKIP> 未加载自定义回复，跳过插件执行。")
            return reply_message
        except Exception as e:
            logger.error(f"<ERROR> {plugin_class_name} 执行时出错: {e}", exc_info=True)
            return reply_message